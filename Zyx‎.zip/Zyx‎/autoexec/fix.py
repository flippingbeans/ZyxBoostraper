import subprocess
import os

# Get the directory of the current script
dir_path = os.path.dirname(os.path.realpath(__file__))

# Assuming the EXEs are in the same directory
exe1 = os.path.join(dir_path, 'first.exe')
exe2 = os.path.join(dir_path, 'second.exe')